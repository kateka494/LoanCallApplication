﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LoanCalApp

{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //Button for option BUY
        private void btnBuy_Click(object sender, RoutedEventArgs e)
        {
            Buy b = new Buy();
            b.Show();
            
        }

        //Button for user to save
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Save s = new Save();
            s.Show();
           
        }

        //Button For Vehicle option
        private void btnVehicle_Click(object sender, RoutedEventArgs e)
        {
            Vehicle v = new Vehicle();
            v.Show();
            
        }

        //Button for rent option
        private void btnRent_Click(object sender, RoutedEventArgs e)
        {
            Rent r= new Rent();
            r.Show();
            
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            double Gross = Convert.ToDouble(txtGross.Text);
            double M_Tax = Convert.ToDouble(txtTax.Text);
            double Groceries = Convert.ToDouble(txtGroceries.Text);
            double Water_Lights = Convert.ToDouble(txtWater.Text);
            double Cell_telephone = Convert.ToDouble(txtCell.Text);
            double OtherExp = Convert.ToDouble(txtOther.Text);

            //Calculates available monthly money from gross income (after expenses are deducted)
            double AvailableMM = Gross - (M_Tax + Groceries + Water_Lights + Cell_telephone + OtherExp);
            
            
            //Displays Expenses entered by the user
            MessageBox.Show("Your Expenses " +
                            "\r\nGross income R:" + Gross +
                             "\r\nMontly tax R:" + M_Tax +
                              "\r\nGroceries R:" + Groceries +
                            "\r\nWater and Lights R:" + Water_Lights +
                             "\r\nCellphone and Telephone bill R :" + Cell_telephone +
                             "\r\nOther expenses R:" + OtherExp +
                  //Also displays available monthly money
                             "\r\n Your available Monthly Money is R:" + AvailableMM

                            ) ;
           
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
