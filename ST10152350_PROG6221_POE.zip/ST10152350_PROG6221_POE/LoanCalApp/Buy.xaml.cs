﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LoanCalApp

{
    /// <summary>
    /// Interaction logic for Buy.xaml
    /// </summary>
    public partial class Buy : Window
    {
        public Buy()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            // simple intrest formula A = P(1 + in)
            
            double PropertyPrice = Convert.ToDouble(txtPropertyPrice.Text);
            double Deposit = Convert.ToDouble(txtDeposit.Text);
            double Interest= Convert.ToDouble(txtInterest.Text);
            double Months= Convert.ToDouble(txtMonths.Text);
            double HomeLoan;
            //This calculates the total home loan amount
            HomeLoan = (PropertyPrice - Deposit) * (1 + (Interest/100) * (Months / 12));
            //This calculates how much will be paid in monthly
            double MontlyRepayment = HomeLoan / Months;

            MessageBox.Show(" Your Total Home Loan Amount is R :" + HomeLoan + "\n Your home loan montly repayment amount is R :" + MontlyRepayment);
            

        }
    }
}
