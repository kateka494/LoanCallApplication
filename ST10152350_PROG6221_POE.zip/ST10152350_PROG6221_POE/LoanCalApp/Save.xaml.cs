﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LoanCalApp

{
    /// <summary>
    /// Interaction logic for Save.xaml
    /// </summary>
    public partial class Save : Window
    {
        public Save()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            double TotAmount = Convert.ToDouble(txtAmountSave.Text);
            int Interest = Convert.ToInt32(txtint.Text);
            int Years = Convert.ToInt32(txtYears.Text);
           
            //Calculates how much the user will have after they saved for the years they specified
            double SavingsAmount  = TotAmount * (1 + Interest * Years);
            //Calculates how much they need to save monthly to reach their goal
            double MontlySavingsAmount = TotAmount /(Years * 12);
            MessageBox.Show(" Your Savings Amount after " + Years + "Years  " + " Is R:"+ SavingsAmount 
                
                           + "\r\nMontly savings amount needed to reach Your Goal is R:" + MontlySavingsAmount +  "\r\n Per month");

            
        }
    }
}
