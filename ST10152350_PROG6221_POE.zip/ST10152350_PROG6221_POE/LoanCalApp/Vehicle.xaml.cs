﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LoanCalApp

{
    /// <summary>
    /// Interaction logic for Vehicle.xaml
    /// </summary>
    public partial class Vehicle : Window
    {
        public Vehicle()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            double PurchasePrice = Convert.ToDouble(txtprice.Text);
            double Deposit = Convert.ToDouble(txtTotaldep.Text);
            double Insurance = Convert.ToDouble(Insure.Text);
            int Interest = Convert.ToInt32(txtRate.Text);

            //Calculates Loan Amount with interest
            double LoanAmt; 
            // A = P(1+in)
            LoanAmt = (PurchasePrice - Deposit) * (1 + ((Interest / 100) * 5));
            //Calculates Monthly Payment with Insurance 
            double M_Payment; 
            M_Payment = (LoanAmt / (5 * 12)) + Insurance;



            MessageBox.Show(" Your Total Veihicle Loan Amount is:" + LoanAmt + 
                "\n Your Monthly Payment (with Insurance) is R" + M_Payment);
            
            



        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
